from collections import deque

from otree.api import *
from datetime import datetime
import random
from .understanding_questions import QUESTIONS

doc = """
Fill the following fields: "order" and "treatment".

Do not change the "treatment" field "TEST".

The orders correspond to: (1: PD, SH, UG), (2: UG, PD, SH), (3: SH, UG, PD).

The number of players have to be multiple of 2. If you want to ensure perfect stranger matching, you need at least 16
players.
"""

PLAYERS1, PLAYERS2, pairs = None, None, None


class C(BaseConstants):
    NAME_IN_URL = 'gblbjp'

    #### BARGAINING

    # Players roles
    PLAYER1_ROLE = 'A'
    PLAYER2_ROLE = 'B'

    # Parameters
    PLAYERS_PER_GROUP = 2
    NUM_ROUNDS = 2
    CONVERSION_RATE = 1
    BARGAINING_TIME = 300
    DISAGREEMENT_PAYOFF_P1 = 0
    DISAGREEMENT_PAYOFF_P2 = 0
    timer = BARGAINING_TIME / 60
    timer_result = 20
    GROWTH_RATE = 1.5  # Resource growth rate
    RISK = 0.5  # Set risk to 50% for all participants
    PIE_SIZE_T1 = 1000  # Initial pie size

    # Treatments
    BG = "bargain"
    PD = "prisoner"
    UG = "ultimatum"
    SH = "staghunt"
    TEST = "test"


class Subsession(BaseSubsession):
    treatment = models.StringField()
    order = models.StringField


def get_pairs(subsession: Subsession):
    nb_participants = len(subsession.get_players())
    PLAYERS1 = [p.id_in_subsession for p in subsession.get_players()[: nb_participants // 2]]
    PLAYERS2 = [p.id_in_subsession for p in subsession.get_players()[nb_participants // 2:]]
    PLAYERS2 = deque(PLAYERS2)

    while True:
        yield list(zip(PLAYERS1, PLAYERS2))
        PLAYERS2.rotate(1)


def creating_session(subsession: Subsession):
    selected_order = subsession.session.config.get('order', 'default_order')
    session_paid_round = random.randint(1, C.NUM_ROUNDS)

    global pairs

    if subsession.round_number == 1:
        pairs = get_pairs(subsession)

    if subsession.round_number == 8:
        for player in subsession.get_players():
            player.paid_round = session_paid_round

    subsession.set_group_matrix(next(pairs))

    for group in subsession.get_groups():
        players = group.get_players()
        for player in players:
            player.round = subsession.round_number

    if subsession.round_number <= 4:
        for player in subsession.get_players():
            if player.id_in_group == 1:
                player.type = "Player 1"
            else:
                player.type = "Player 2"

    if subsession.round_number > 4:
        for player in subsession.get_players():
            if player.id_in_group == 1:
                player.id_in_group = 2
                player.type = "Player 2"
            else:
                player.id_in_group = 1
                player.type = "Player 1"


class Group(BaseGroup):
    share_price = models.CurrencyField()
    is_finished = models.BooleanField(initial=False)
    is_stopped = models.BooleanField(initial=False)
    total_extraction_t1 = models.FloatField(initial=0)  # Track total extraction in Period 1
    pie_size_t2 = models.FloatField(initial=C.PIE_SIZE_T1)  # Updated pie size for Period 2

    def update_pie_size_t2(self):
        remaining_pie = C.PIE_SIZE_T1 - self.total_extraction_t1
        self.pie_size_t2 = remaining_pie * C.GROWTH_RATE  # Apply growth rate to remaining pie



class Player(BasePlayer):
    has_read_instructions = models.BooleanField(initial=False)
    paid_round = models.IntegerField()
    main_task_payoff = models.IntegerField()
    converted_payoff = models.IntegerField()
    total_payoff = models.CurrencyField()
    participation_fee = models.CurrencyField()
    round = models.IntegerField()
    treatment = models.StringField()
    treatment_order = models.IntegerField()
    type = models.StringField()
    instructions_start_time = models.StringField()
    instructions_end_time = models.StringField()

    amount_player1 = models.IntegerField(initial=0)
    amount_player2 = models.IntegerField(initial=0)

    # Separate extraction and guessing fields for P1 and P2 in Period 1 and Period 2
    extract_me_p1_t1 = models.FloatField(min=0)
    guess_other_p1_t1 = models.FloatField(min=0)
    extract_me_p2_t1 = models.FloatField(min=0)
    guess_other_p2_t1 = models.FloatField(min=0)

    extract_me_p1_t2 = models.FloatField(min=0)  # Period 2 fields
    guess_other_p1_t2 = models.FloatField(min=0)
    extract_me_p2_t2 = models.FloatField(min=0)
    guess_other_p2_t2 = models.FloatField(min=0)

    # BARGAINING

    amount_proposed_player1 = models.IntegerField()
    amount_proposed_player2 = models.IntegerField()
    amount_accepted_player1 = models.IntegerField()
    amount_accepted_player2 = models.IntegerField()
    offers_made_player1 = models.LongStringField(initial="")
    offers_made_player2 = models.LongStringField(initial="")
    accepted_shares = models.LongStringField(initial="")
    timeout_occurred = models.BooleanField(initial=False)
    player1_share = models.IntegerField()
    player2_share = models.IntegerField()
    bargain_start_time = models.StringField()
    bargain_end_time = models.StringField()
    stopped_by_player_id = models.IntegerField(initial=0)

    def set_accepted_shares(self, player1_share, player2_share):
        self.accepted_shares = str([player1_share, player2_share])
        self.player1_share = player1_share
        self.player2_share = player2_share

    def add_offer_player1(self, offer):
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        offer_with_time = {'offer': offer, 'time': current_time}
        offers = self.get_offers_player1()
        offers.append(offer_with_time)
        self.offers_made_player1 = str(offers)

    def get_offers_player1(self):
        if self.offers_made_player1:
            return eval(self.offers_made_player1)
        else:
            return []

    def add_offer_player2(self, offer):
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        offer_with_time = {'offer': offer, 'time': current_time}
        offers = self.get_offers_player2()
        offers.append(offer_with_time)
        self.offers_made_player2 = str(offers)

    def get_offers_player2(self):
        if self.offers_made_player2:
            return eval(self.offers_made_player2)
        else:
            return []

def chat_nickname(player):
    return 'プレイヤー{}'.format(player.id_in_group)

def chat_nickname_me(player):
    return 'プレイヤー{} (私)'.format(player.id_in_group)

def calculate_faults(player):
    player.understanding_faults = sum([getattr(player, f'understanding_faults{i}') for i in range(1, 8)])


########################################################################################################################
########################################################################################################################
########################################################################################################################

class BargainP1(Page):
    timer_text = '交渉の残り時間：'

    def get(self):
        self.player.bargain_start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return super().get()

    timeout_seconds = C.BARGAINING_TIME

    @staticmethod
    def vars_for_template(player: Player):
        max_extraction = C.PIE_SIZE_T1 / 2  # Maximum extraction for Period 1
        return {
            'other_type': player.get_others_in_group()[0].type,
            'nickname': chat_nickname(player),
            'nickname_i_see_for_myself': chat_nickname_me(player),
            'total_resource': f"Total resource: {C.PIE_SIZE_T1}",
            'max_extraction': f"Maximum extraction amount for each participant: {max_extraction}",
            'growth_rate': f"The resource growth rate: {(C.GROWTH_RATE - 1) * 100}%",
            'risk_info': f"The possibility that the total resource will be wiped out and become 0 in the next period: {C.RISK * 100}%",
        }


    @staticmethod
    def js_vars(player: Player):
        return dict(my_id=player.id_in_group)

    @staticmethod
    def live_method(player: Player, data):
        print("Received data:", data)
        group = player.group
        [other] = player.get_others_in_group()

        if 'amount_player1' in data and 'amount_player2' in data:
            try:
                amount_player1 = int(data['amount_player1'])
                amount_player2 = int(data['amount_player2'])
            except ValueError:
                print('Invalid message received', data)
                return

            if data['type'] == 'accept':
                if amount_player1 == other.amount_proposed_player1 and amount_player2 == other.amount_proposed_player2:
                    player.amount_accepted_player1 = amount_player1
                    player.amount_accepted_player2 = amount_player2
                    group.share_price = amount_player1 + amount_player2
                    group.is_finished = True
                    player.set_accepted_shares(amount_player1, amount_player2)
                    other.set_accepted_shares(amount_player1, amount_player2)
                    print(f"Sending finished=True for player {player.id_in_group}")
                    return {0: dict(finished=True)}

            if data['type'] == 'propose':
                player.amount_proposed_player1 = amount_player1
                player.amount_proposed_player2 = amount_player2
                player.add_offer_player1(amount_player1)
                player.add_offer_player2(amount_player2)

            if data['type'] == 'stop_bargaining':
                default_share_player1 = C.DISAGREEMENT_PAYOFF_P1
                default_share_player2 = C.DISAGREEMENT_PAYOFF_P2

                player.amount_accepted_player1 = default_share_player1
                player.amount_accepted_player2 = default_share_player2
                player.set_accepted_shares(default_share_player1, default_share_player2)

                other.amount_accepted_player1 = default_share_player1
                other.amount_accepted_player2 = default_share_player2
                other.set_accepted_shares(default_share_player1, default_share_player2)

                player.stopped_by_player_id = player.id_in_group
                other.stopped_by_player_id = player.id_in_group

                group.share_price = default_share_player1 + default_share_player2
                group.is_finished = True
                group.is_stopped = True

                print(f"Sending finished=True for player {player.id_in_group}")
                return {0: dict(finished=True)}

        proposals = []
        for p in [player, other]:
            amount_proposed_player1 = p.field_maybe_none('amount_proposed_player1')
            amount_proposed_player2 = p.field_maybe_none('amount_proposed_player2')
            if amount_proposed_player1 is not None and amount_proposed_player2 is not None:
                proposals.append([p.id_in_group, amount_proposed_player1, amount_proposed_player2])

        return {0: dict(proposals=proposals)}

    # @staticmethod
    # def error_message(player: Player, values):
    #     group = player.group
    #     if not group.is_finished:
    #         return " TEST ERROR MESSAGE "

    @staticmethod
    def is_displayed(player: Player):
        group = player.group
        share_price = group.field_maybe_none('share_price')
        return share_price is None

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        if timeout_happened:
            group = player.group
            player.timeout_occurred = True

            default_share_player1 = C.DISAGREEMENT_PAYOFF_P1
            default_share_player2 = C.DISAGREEMENT_PAYOFF_P2
            player.amount_accepted_player1 = default_share_player1
            player.amount_accepted_player2 = default_share_player2
            player.set_accepted_shares(default_share_player1, default_share_player2)
            group.share_price = default_share_player1 + default_share_player2
        else:
            player.timeout_occurred = False
        player.bargain_end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

class BLWaitForGroupP1(WaitPage):
    @staticmethod
    def after_all_players_arrive(group: Group):
        # Calculate the remaining pie after Period 1 extractions
        remaining_pie = C.PIE_SIZE_T1 - group.total_extraction_t1

        # Apply risk factor to determine if the pie is wiped out
        if random.random() < C.RISK:
            group.pie_size_t2 = 0  # Pie is wiped out
        else:
            group.pie_size_t2 = remaining_pie * C.GROWTH_RATE  # Apply growth rate to remaining pie

        # Debug log for consistency check
        print(f"Group {group.id_in_subsession}: pie_size_t2 = {group.pie_size_t2}")

        # Call the payoffs method
        BLWaitForGroupP1.set_payoffs_bargain(group)

    @staticmethod
    def set_payoffs_bargain(group: Group):
        player1, player2 = group.get_players()

        if group.is_finished:
            player1.payoff = int(player1.player1_share)
            player2.payoff = int(player2.player2_share)
        else:
            player1.payoff = C.DISAGREEMENT_PAYOFF_P1
            player2.payoff = C.DISAGREEMENT_PAYOFF_P2

        player1.player1_share = int(player1.payoff)
        player1.player2_share = int(player2.payoff)
        player2.player1_share = int(player1.payoff)
        player2.player2_share = int(player2.payoff)

        player1.set_accepted_shares(player1.player1_share, player1.player2_share)
        player2.set_accepted_shares(player2.player1_share, player2.player2_share)


class ResultsP1(Page):
    timer_text = '交渉の残り時間：'
    @staticmethod
    def vars_for_template(player: Player):
        if player.accepted_shares:
            accepted_shares = eval(player.accepted_shares)
            player1_share, player2_share = accepted_shares[0], accepted_shares[1]
        else:
            player1_share, player2_share = 0, 0

        return {
            'player1_share': player1_share,
            'player2_share': player2_share,
            'timeout_occurred': player.timeout_occurred
        }

    timeout_seconds = C.timer_result

    @staticmethod
    def after_all_players_arrive(player: Player, timeout_happened):
        group = player.group
        group.total_extraction_t1 += player.player1_share+player.player2_share
        remaining_pie = C.PIE_SIZE_T1 - group.total_extraction_t1
        if random.random() < C.RISK:
            group.pie_size_t2 = 0  # Apply risk, pie becomes 0
        else:
            group.pie_size_t2 = remaining_pie * C.GROWTH_RATE

class BargainP2(Page):
    timer_text = '交渉の残り時間：'

    def get(self):
        self.player.bargain_start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return super().get()

    timeout_seconds = C.BARGAINING_TIME

    @staticmethod
    def vars_for_template(player: Player):
        group = player.group  # Access the group object
        total_resource = group.pie_size_t2  # Use the group's pie size
        max_extraction = group.pie_size_t2 / 2  # Directly calculate the maximum extraction amount

        return {
            'other_type': player.get_others_in_group()[0].type,
            'nickname': chat_nickname(player),
            'nickname_i_see_for_myself': chat_nickname_me(player),
            'total_resource': f"Total resource: {total_resource}",
            'max_extraction': f"Maximum extraction amount for each participant: {max_extraction}",
            'growth_rate': f"The resource growth rate: {(C.GROWTH_RATE - 1) * 100}%",
            'risk_info': f"The possibility that the total resource will be wiped out and become 0 in the next period: {C.RISK * 100}%",
        }

    @staticmethod
    def js_vars(player: Player):
        group = player.group
        return {
            'my_id': player.id_in_group,
            'total_resource': group.pie_size_t2,  # Ensure correct pie size
        }

    @staticmethod
    def live_method(player: Player, data):
        print("Received data:", data)
        group = player.group
        [other] = player.get_others_in_group()

        if 'amount_player1' in data and 'amount_player2' in data:
            try:
                amount_player1 = int(data['amount_player1'])
                amount_player2 = int(data['amount_player2'])
            except ValueError:
                print('Invalid message received', data)
                return

            if data['type'] == 'accept':
                if amount_player1 == other.amount_proposed_player1 and amount_player2 == other.amount_proposed_player2:
                    player.amount_accepted_player1 = amount_player1
                    player.amount_accepted_player2 = amount_player2
                    group.share_price = amount_player1 + amount_player2
                    group.is_finished = True
                    player.set_accepted_shares(amount_player1, amount_player2)
                    other.set_accepted_shares(amount_player1, amount_player2)
                    print(f"Sending finished=True for player {player.id_in_group}")
                    return {0: dict(finished=True)}

            if data['type'] == 'propose':
                player.amount_proposed_player1 = amount_player1
                player.amount_proposed_player2 = amount_player2
                player.add_offer_player1(amount_player1)
                player.add_offer_player2(amount_player2)

            if data['type'] == 'stop_bargaining':
                default_share_player1 = C.DISAGREEMENT_PAYOFF_P1
                default_share_player2 = C.DISAGREEMENT_PAYOFF_P2

                player.amount_accepted_player1 = default_share_player1
                player.amount_accepted_player2 = default_share_player2
                player.set_accepted_shares(default_share_player1, default_share_player2)

                other.amount_accepted_player1 = default_share_player1
                other.amount_accepted_player2 = default_share_player2
                other.set_accepted_shares(default_share_player1, default_share_player2)

                player.stopped_by_player_id = player.id_in_group
                other.stopped_by_player_id = player.id_in_group

                group.share_price = default_share_player1 + default_share_player2
                group.is_finished = True
                group.is_stopped = True

                print(f"Sending finished=True for player {player.id_in_group}")
                return {0: dict(finished=True)}

        proposals = []
        for p in [player, other]:
            amount_proposed_player1 = p.field_maybe_none('amount_proposed_player1')
            amount_proposed_player2 = p.field_maybe_none('amount_proposed_player2')
            if amount_proposed_player1 is not None and amount_proposed_player2 is not None:
                proposals.append([p.id_in_group, amount_proposed_player1, amount_proposed_player2])

        return {0: dict(proposals=proposals)}

    # @staticmethod
    # def error_message(player: Player, values):
    #     group = player.group
    #     if not group.is_finished:
    #         return " TEST ERROR MESSAGE "



    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        if timeout_happened:
            group = player.group
            player.timeout_occurred = True

            default_share_player1 = C.DISAGREEMENT_PAYOFF_P1
            default_share_player2 = C.DISAGREEMENT_PAYOFF_P2
            player.amount_accepted_player1 = default_share_player1
            player.amount_accepted_player2 = default_share_player2
            player.set_accepted_shares(default_share_player1, default_share_player2)
            group.share_price = default_share_player1 + default_share_player2
        else:
            player.timeout_occurred = False
        player.bargain_end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

class BLWaitForGroupP2(WaitPage):
    @staticmethod
    def after_all_players_arrive(group: Group):
        BLWaitForGroupP2.set_payoffs_bargain(group)

    @staticmethod
    def set_payoffs_bargain(group: Group):
        player1, player2 = group.get_players()

        if group.is_finished:
            player1.payoff = int(player1.player1_share)
            player2.payoff = int(player2.player2_share)
        else:
            player1.payoff = C.DISAGREEMENT_PAYOFF_P1
            player2.payoff = C.DISAGREEMENT_PAYOFF_P2

        player1.player1_share = int(player1.payoff)
        player1.player2_share = int(player2.payoff)
        player2.player1_share = int(player1.payoff)
        player2.player2_share = int(player2.payoff)

        player1.set_accepted_shares(player1.player1_share, player1.player2_share)
        player2.set_accepted_shares(player2.player1_share, player2.player2_share)


class ResultsP2(Page):
    timer_text = '交渉の残り時間：'
    @staticmethod
    def vars_for_template(player: Player):
        if player.accepted_shares:
            accepted_shares = eval(player.accepted_shares)
            player1_share, player2_share = accepted_shares[0], accepted_shares[1]
        else:
            player1_share, player2_share = 0, 0

        return {
            'player1_share': player1_share,
            'player2_share': player2_share,
            'timeout_occurred': player.timeout_occurred
        }

    timeout_seconds = C.timer_result

class InstructionsWaitForAll(WaitPage):
    wait_for_all_groups = True


class WaitForAllGroup(WaitPage):
    wait_for_all_groups = True


class FinalWaitForAll(WaitPage):
    wait_for_all_groups = True

    @staticmethod
    def is_displayed(player: Player):
        return player.round_number == C.NUM_ROUNDS


class FinalResultsPage(Page):

    @staticmethod
    def is_displayed(player: Player):
        return player.round_number == C.NUM_ROUNDS

    @staticmethod
    def vars_for_template(player: Player):
        selected_round_player = player.in_round(player.paid_round)
        player.main_task_payoff = int(selected_round_player.payoff)

        player.converted_payoff = int(player.main_task_payoff * C.CONVERSION_RATE)

        player.total_payoff = player.converted_payoff

        round_details = []
        for round_number, p in enumerate(player.in_all_rounds(), start=1):
            round_details.append({
                'round_number': round_number,
                'payoff': p.payoff,
                'is_paid_round': (round_number == player.paid_round)
            })

        return {
            'round_details': round_details,
            'paid_round': player.paid_round,
            'main_task_payoff': player.main_task_payoff,
            'converted_payoff': player.converted_payoff,
            'total_payoff': player.total_payoff
        }

    def before_next_page(player, timeout_happened):
        player.participant.vars['bargain_payoff'] = player.total_payoff
        player.participant.vars['bargain_paid_round'] = player.paid_round


class FinalResultsPage_save(Page):
    timer_text = '交渉の残り時間：'

    @staticmethod
    def is_displayed(player: Player):
        return player.round_number == C.NUM_ROUNDS

    @staticmethod
    def vars_for_template(player: Player):
        selected_round_player = player.in_round(player.paid_round)
        player.main_task_payoff = int(selected_round_player.payoff)

        player.converted_payoff = int(player.main_task_payoff * C.CONVERSION_RATE)

        player.total_payoff = player.converted_payoff

        round_details = []
        for round_number, p in enumerate(player.in_all_rounds(), start=1):
            round_details.append({
                'round_number': round_number,
                'payoff': p.payoff,
                'is_paid_round': (round_number == player.paid_round)
            })

        return {
            'round_details': round_details,
            'paid_round': player.paid_round,
            'main_task_payoff': player.main_task_payoff,
            'converted_payoff': player.converted_payoff,
            'total_payoff': player.total_payoff
        }

    def before_next_page(player, timeout_happened):
        player.participant.vars['bargain_payoff'] = player.total_payoff
        player.participant.vars['bargain_paid_round'] = player.paid_round


########################################################################################################################
########################################################################################################################
########################################################################################################################



page_sequence = [ BargainP1,BLWaitForGroupP1,ResultsP1,BargainP2,BLWaitForGroupP2,ResultsP2,
                 WaitForAllGroup,FinalWaitForAll,
                 # FinalResultsPage,
                 FinalResultsPage_save
                 ]
