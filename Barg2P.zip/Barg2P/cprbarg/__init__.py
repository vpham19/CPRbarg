from collections import deque
from otree.api import *
from datetime import datetime
import random


class C(BaseConstants):
    NAME_IN_URL = 'cprbarg'
    PLAYERS_PER_GROUP = 2
    NUM_ROUNDS = 8
    BARGAINING_TIME = 180
    GROWTH_RATE = 1.5  # Resource growth rate
    NUM_PERIODS = 2
    RISK = 0.5  # Set risk to 50% for all participants
    PIE_SIZE_T1 = 1000  # Initial pie size


class Subsession(BaseSubsession):
    # Global variable to store pairs
    global pairs

    def creating_subsession(self):
        # Store the current round number for each player
        for player in self.get_players():
            player.current_round = self.round_number

        # Get pairs and rotate them to ensure variety in matching
        if self.round_number == 1:
            pairs = self.get_pairs()

        self.set_group_matrix(next(pairs))
        print(f"Groups randomized in round {self.round_number}")

        # Debug: Print group formation for each round
        for group in self.get_groups():
            players = group.get_players()
            print(f"Group {group.id_in_subsession}: {[p.id_in_subsession for p in players]}")

    def get_pairs(self):
        nb_participants = len(self.get_players())
        PLAYERS1 = [p.id_in_subsession for p in self.get_players()[: nb_participants // 2]]
        PLAYERS2 = [p.id_in_subsession for p in self.get_players()[nb_participants // 2:]]
        PLAYERS2 = deque(PLAYERS2)

        # Use deque to rotate player pairs
        while True:
            yield list(zip(PLAYERS1, PLAYERS2))
            PLAYERS2.rotate(1)


class Group(BaseGroup):
    total_extraction_t1 = models.FloatField(initial=0)  # Track total extraction in Period 1
    pie_size_t2 = models.FloatField(initial=C.PIE_SIZE_T1)  # Updated pie size for Period 2
    share_price = models.CurrencyField()
    is_finished = models.BooleanField(initial=False)
    is_stopped = models.BooleanField(initial=False)

    def update_pie_size_t2(self):
        remaining_pie = C.PIE_SIZE_T1 - self.total_extraction_t1
        self.pie_size_t2 = remaining_pie * C.GROWTH_RATE  # Apply growth rate to remaining pie


class Player(BasePlayer):
    has_read_instructions = models.BooleanField(initial=False)
    paid_round = models.IntegerField()
    main_task_payoff = models.IntegerField()
    converted_payoff = models.IntegerField()
    total_payoff = models.CurrencyField()
    participation_fee = models.CurrencyField()
    current_round = models.IntegerField()

    # Separate extraction and guessing fields for P1 and P2 in Period 1 and Period 2
    extract_me_p1_t1 = models.FloatField(min=0)
    guess_other_p1_t1 = models.FloatField(min=0)
    extract_me_p2_t1 = models.FloatField(min=0)
    guess_other_p2_t1 = models.FloatField(min=0)

    extract_me_p1_t2 = models.FloatField(min=0)  # Period 2 fields
    guess_other_p1_t2 = models.FloatField(min=0)
    extract_me_p2_t2 = models.FloatField(min=0)
    guess_other_p2_t2 = models.FloatField(min=0)

# BARGAINING

    amount_proposed_player1 = models.IntegerField()
    amount_proposed_player2 = models.IntegerField()
    amount_accepted_player1 = models.IntegerField()
    amount_accepted_player2 = models.IntegerField()
    offers_made_player1 = models.LongStringField(initial="")
    offers_made_player2 = models.LongStringField(initial="")
    accepted_shares = models.LongStringField(initial="")
    timeout_occurred = models.BooleanField(initial=False)
    player1_share = models.IntegerField()
    player2_share = models.IntegerField()
    bargain_start_time = models.StringField()
    bargain_end_time = models.StringField()
    stopped_by_player_id = models.IntegerField(initial=0)

    def set_accepted_shares(self, player1_share, player2_share):
        self.accepted_shares = str([player1_share, player2_share])
        self.player1_share = player1_share
        self.player2_share = player2_share

    def add_offer_player1(self, offer):
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        offer_with_time = {'offer': offer, 'time': current_time}
        offers = self.get_offers_player1()
        offers.append(offer_with_time)
        self.offers_made_player1 = str(offers)

    def get_offers_player1(self):
        if self.offers_made_player1:
            return eval(self.offers_made_player1)
        else:
            return []

    def add_offer_player2(self, offer):
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        offer_with_time = {'offer': offer, 'time': current_time}
        offers = self.get_offers_player2()
        offers.append(offer_with_time)
        self.offers_made_player2 = str(offers)

    def get_offers_player2(self):
        if self.offers_made_player2:
            return eval(self.offers_made_player2)
        else:
            return []

def chat_nickname(player):
    return 'プレイヤー{}'.format(player.id_in_group)

def chat_nickname_me(player):
    return 'プレイヤー{} (私)'.format(player.id_in_group)

def calculate_faults(player):
    player.understanding_faults = sum([getattr(player, f'understanding_faults{i}') for i in range(1, 8)])

class Bargain1(Page):
    timer_text = '交渉の残り時間：'

    def get(self):
        self.player.bargain_start_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        return super().get()

    timeout_seconds = C.BARGAINING_TIME

    @staticmethod
    def vars_for_template(player: Player):
        return dict(
                    nickname=chat_nickname(player),
                    nickname_i_see_for_myself=chat_nickname_me(player)
                    )

    @staticmethod
    def js_vars(player: Player):
        return dict(my_id=player.id_in_group)

    @staticmethod
    def live_method(player: Player, data):
        print("Received data:", data)
        group = player.group
        [other] = player.get_others_in_group()

        if 'amount_player1' in data and 'amount_player2' in data:
            try:
                amount_player1 = int(data['amount_player1'])
                amount_player2 = int(data['amount_player2'])
            except ValueError:
                print('Invalid message received', data)
                return

            if data['type'] == 'accept':
                if amount_player1 == other.amount_proposed_player1 and amount_player2 == other.amount_proposed_player2:
                    player.amount_accepted_player1 = amount_player1
                    player.amount_accepted_player2 = amount_player2
                    group.share_price = amount_player1 + amount_player2
                    group.is_finished = True
                    player.set_accepted_shares(amount_player1, amount_player2)
                    other.set_accepted_shares(amount_player1, amount_player2)
                    print(f"Sending finished=True for player {player.id_in_group}")
                    return {0: dict(finished=True)}

            if data['type'] == 'propose':
                player.amount_proposed_player1 = amount_player1
                player.amount_proposed_player2 = amount_player2
                player.add_offer_player1(amount_player1)
                player.add_offer_player2(amount_player2)

            if data['type'] == 'stop_bargaining':
                default_share_player1 = C.DISAGREEMENT_PAYOFF_P1
                default_share_player2 = C.DISAGREEMENT_PAYOFF_P2

                player.amount_accepted_player1 = default_share_player1
                player.amount_accepted_player2 = default_share_player2
                player.set_accepted_shares(default_share_player1, default_share_player2)

                other.amount_accepted_player1 = default_share_player1
                other.amount_accepted_player2 = default_share_player2
                other.set_accepted_shares(default_share_player1, default_share_player2)

                player.stopped_by_player_id = player.id_in_group
                other.stopped_by_player_id = player.id_in_group

                group.share_price = default_share_player1 + default_share_player2
                group.is_finished = True
                group.is_stopped = True

                print(f"Sending finished=True for player {player.id_in_group}")
                return {0: dict(finished=True)}

        proposals = []
        for p in [player, other]:
            amount_proposed_player1 = p.field_maybe_none('amount_proposed_player1')
            amount_proposed_player2 = p.field_maybe_none('amount_proposed_player2')
            if amount_proposed_player1 is not None and amount_proposed_player2 is not None:
                proposals.append([p.id_in_group, amount_proposed_player1, amount_proposed_player2])

        return {0: dict(proposals=proposals)}

    # @staticmethod
    # def error_message(player: Player, values):
    #     group = player.group
    #     if not group.is_finished:
    #         return " TEST ERROR MESSAGE "

    @staticmethod
    def is_displayed(player: Player):
        group = player.group
        share_price = group.field_maybe_none('share_price')
        return share_price is None

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        if timeout_happened:
            group = player.group
            player.timeout_occurred = True

            default_share_player1 = C.DISAGREEMENT_PAYOFF_P1
            default_share_player2 = C.DISAGREEMENT_PAYOFF_P2
            player.amount_accepted_player1 = default_share_player1
            player.amount_accepted_player2 = default_share_player2
            player.set_accepted_shares(default_share_player1, default_share_player2)
            group.share_price = default_share_player1 + default_share_player2
        else:
            player.timeout_occurred = False
        player.bargain_end_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")


class BLWaitForGroup(WaitPage):
    @staticmethod
    def after_all_players_arrive(group: Group):
        BLWaitForGroup.set_payoffs_bargain(group)

    @staticmethod
    def set_payoffs_bargain(group: Group):
        player1, player2 = group.get_players()

        if group.is_finished:
            player1.payoff = int(player1.player1_share)
            player2.payoff = int(player2.player2_share)
        else:
            player1.payoff = C.DISAGREEMENT_PAYOFF_P1
            player2.payoff = C.DISAGREEMENT_PAYOFF_P2

        player1.player1_share = int(player1.payoff)
        player1.player2_share = int(player2.payoff)
        player2.player1_share = int(player1.payoff)
        player2.player2_share = int(player2.payoff)

        player1.set_accepted_shares(player1.player1_share, player1.player2_share)
        player2.set_accepted_shares(player2.player1_share, player2.player2_share)


class CPR1(Page):
    form_model = 'player'

    @staticmethod
    def get_form_fields(player: Player):
        if player.id_in_group == 1:
            return ['extract_me_p1_t1', 'guess_other_p1_t1']
        elif player.id_in_group == 2:
            return ['extract_me_p2_t1', 'guess_other_p2_t1']

    @staticmethod
    def vars_for_template(player: Player):
        max_extraction = C.PIE_SIZE_T1 / 2  # Maximum extraction for Period 1
        return {
            'total_resource': f"Total resource: {C.PIE_SIZE_T1}",
            'max_extraction': max_extraction,
            'growth_rate': f"The resource growth rate: {(C.GROWTH_RATE - 1) * 100}%",
            'risk_info': f"The possibility that the total resource will be wiped out and become 0 in the next period: {C.RISK * 100}%",
        }

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        group = player.group
        if player.id_in_group == 1:
            group.total_extraction_t1 += player.extract_me_p1_t1
        elif player.id_in_group == 2:
            group.total_extraction_t1 += player.extract_me_p2_t1

        # Update the pie size for Period 2 (after deduction)
        if player.round_number == 1:
            group.update_pie_size_t2()  # Apply the correct logic to update pie size for Period 2


class Period1WaitPage(WaitPage):
    body_text = "Please wait for the other participant to finish."

    @staticmethod
    def after_all_players_arrive(group: Group):
        remaining_pie = C.PIE_SIZE_T1 - group.total_extraction_t1
        if random.random() < C.RISK:
            group.pie_size_t2 = 0  # Apply risk, pie becomes 0
        else:
            group.pie_size_t2 = remaining_pie * C.GROWTH_RATE


class FeedbackPeriod1(Page):
    @staticmethod
    def vars_for_template(player: Player):
        p1_extraction = player.group.get_player_by_id(1).field_maybe_none('extract_me_p1_t1') or 0
        p2_extraction = player.group.get_player_by_id(2).field_maybe_none('extract_me_p2_t1') or 0
        total_extraction = p1_extraction + p2_extraction
        remaining_pie = C.PIE_SIZE_T1 - total_extraction

        if player.id_in_group == 1:
            message = f"You have extracted: {p1_extraction}.<br>The other participant has extracted: {p2_extraction}.<br>Remaining pie: {remaining_pie}."
        else:
            message = f"You have extracted: {p2_extraction}.<br>The other participant has extracted: {p1_extraction}.<br>Remaining pie: {remaining_pie}."

        return {
            'message': message,
            'your_extraction': p1_extraction if player.id_in_group == 1 else p2_extraction,
            'other_extraction': p2_extraction if player.id_in_group == 1 else p1_extraction,
            'remaining_pie': remaining_pie,
        }


class CPR2(Page):
    form_model = 'player'

    @staticmethod
    def get_form_fields(player: Player):
        if player.id_in_group == 1:
            return ['extract_me_p1_t2', 'guess_other_p1_t2']
        elif player.id_in_group == 2:
            return ['extract_me_p2_t2', 'guess_other_p2_t2']

    @staticmethod
    def vars_for_template(player: Player):
        group = player.group
        max_extraction = group.pie_size_t2 / 2  # Maximum extraction for Period 2

        return {
            'total_resource': f"Total resource: {group.pie_size_t2}",
            'max_extraction': max_extraction,
            'growth_rate': f"The resource growth rate: {(C.GROWTH_RATE - 1) * 100}%",
            'risk_info': f"The possibility that the total resource will be wiped out and become 0 in the next period: {C.RISK * 100}%",
        }

    @staticmethod
    def before_next_page(player: Player, timeout_happened):
        # No need to update pie size here, as it will be handled after all players arrive on the wait page.
        pass


class Period2WaitPage(WaitPage):
    body_text = "Please wait for the other participant to finish."

    @staticmethod
    def after_all_players_arrive(group: Group):
        pass


class FeedbackPeriod2(Page):
    @staticmethod
    def vars_for_template(player: Player):
        # Get the updated pie size after growth and risk adjustments in the wait page
        group = player.group

        # Period 2 extraction amounts
        p1_extraction = group.get_player_by_id(1).field_maybe_none('extract_me_p1_t2') or 0
        p2_extraction = group.get_player_by_id(2).field_maybe_none('extract_me_p2_t2') or 0

        # Calculate the total extraction for Period 2 and the remaining pie size
        total_extraction = p1_extraction + p2_extraction
        remaining_pie = group.pie_size_t2 - total_extraction  # Use updated pie size from Period 2

        # Display feedback based on the player's ID
        if player.id_in_group == 1:
            message = f"You have extracted: {p1_extraction}.<br>The other participant has extracted: {p2_extraction}.<br>Remaining pie: {remaining_pie}."
        else:
            message = f"You have extracted: {p2_extraction}.<br>The other participant has extracted: {p1_extraction}.<br>Remaining pie: {remaining_pie}."

        return {
            'message': message,
            'your_extraction': p1_extraction if player.id_in_group == 1 else p2_extraction,
            'other_extraction': p2_extraction if player.id_in_group == 1 else p1_extraction,
            'remaining_pie': remaining_pie,  # Remaining pie after all extractions
        }


class BeforeNextRoundWaitPage(WaitPage):
    wait_for_all_groups = True


page_sequence = [
    Bargain1, BLWaitForGroup,CPR1,
    Period1WaitPage,
    FeedbackPeriod1,
    CPR2,
    Period2WaitPage,  # Ensure players are synced in Period 2
    FeedbackPeriod2,
    BeforeNextRoundWaitPage
]
